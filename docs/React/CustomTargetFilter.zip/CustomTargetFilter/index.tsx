import React, { useEffect, useState } from 'react'
import { FormComponentProps } from 'antd/lib/form/Form'
import styles from './index.less'

import { Button, Col, Popconfirm, Row, Spin, Tag } from 'antd'
import CustomTargetFilterItem from './components/CustomTargetFilterItem'
import { cloneDeep, omit } from 'lodash'
import { getAddData } from '../DefineRuleV2/utils.func'

interface CustomTargetFilterProps extends FormComponentProps {
    nullList: any[]
    rules: any[]
    ruleData: any[]
    loading: boolean
}

const CustomTargetFilter: React.FC<CustomTargetFilterProps> = (props: CustomTargetFilterProps) => {
    const { form, nullList, rules, ruleData, loading } = props
    const { getFieldValue, setFieldsValue } = form

    const [filter, setFilter] = useState<any>([])
    const [globalLogical, setGlobalLogical] = useState('and')

    const hasOptinsFlag = ruleData.flatMap(it => it.children).filter(Boolean).length > 0

    useEffect(() => {
        const list = rules.map((it, index) => {
            return {
                ...it,
                details: it.details ? it.details : [],
                logical: 'and'
            }
        })
        setFilter(list)
    }, [rules])

    useEffect(() => {
        setGlobalLogical(getFieldValue('rule_logical'))
    }, [getFieldValue('rule_logical')])

    useEffect(() => {
        setFieldsValue({
            real_rule_json: filter,
        })
    }, [filter])

    const handleLogicalChange = (index, newLogical, parentIndex) => {
        //孙条件
        if (filter[parentIndex]?.children) {
            setFilter((prev) => {
                const newFilter = [...prev]
                newFilter[parentIndex].children[index].logical = newLogical
                return newFilter
            })
        } else {
            setFilter((prev) => {
                const newFilter = [...prev]
                newFilter[index].logical = newLogical
                return newFilter
            })
        }
    }

    const handleAddCondition = (index?, parentIndex?) => {
        setFilter((prev) => {
            const newCondition = getAddData(ruleData)
            const newFilter = [...prev]
            //子条件
            if (newFilter[index] && parentIndex === null) {
                if (newFilter[index]['details']) {
                    newFilter[index]['details'].push(newCondition)
                } else {
                    newFilter[index]['details'] = []
                    newFilter[index]['details'].push(newCondition)
                }
            }
            //孙条件
            else if (newFilter[parentIndex]?.details) {
                newFilter[parentIndex].details.forEach((item, cIndex) => {
                    if (cIndex === index) {
                        if (item['children']) {
                            item['children'].push(newCondition)
                        } else {
                            item['children'] = []
                            item['children'].push(newCondition)
                        }
                    }
                })
            }
            else {
                newFilter.push({
                    ...newCondition,
                    logical: 'and',
                    details: [],
                })
            }
            return newFilter
        })
    }

    /**
     * 删除时，只剩下一个条件的时候，进行处理
     * @param newList 
     */
    const handleOnlyData = (newList) => {
        let list = []
        newList.forEach(item => {
            const data = omit(item, ['details', 'logical'])
            list.push({
                ...data,
                details: [],
                logical: 'and'
            })
            if (item.details?.length > 0) {
                item.details.forEach(child => {
                    const data = omit(child, ['children', 'logical'])
                    list.push({
                        ...data,
                        children: [],
                        logical: 'and'
                    })
                })
            }
        })
        setFilter(list)
        setGlobalLogical(newList[0].logical)
    }

    const handleDeleteCondition = (dIndex, parentIndex) => {
        const isParent = parentIndex === null
        if (isParent) {
            const newList = filter.filter((f, index) => index !== dIndex)
            setFilter(newList)
            if (newList.length <= 1) {
                setGlobalLogical('and')
            }
            if (newList.length === 1) {
                handleOnlyData(newList)
            }
        } else {
            //删除子条件
            const newList = filter.map((filter, index) => {
                if (index === parentIndex) {
                    filter.details = filter.details.filter((child, cIndex) => cIndex !== dIndex)
                    if (filter.details.length <= 1) {
                        filter.logical = 'and'
                    }
                }
                return filter
            })
            if (newList.length === 1) {
                handleOnlyData(newList)
            } else {
                setFilter(newList)
            }
        }
    }

    const handleDeleteAll = () => {
        setFilter([])
        setGlobalLogical('and')
    }

    const handleUpdateCondition = (record, i, parentIndex) => {
        const list = cloneDeep(filter)
        if (parentIndex === null) {
            list[i] = {
                ...list[i],
                ...record,
            }
            setFilter(list)
        } else {
            list[parentIndex].details[i] = { ...list[parentIndex].details[i], ...record }
            setFilter(list)
        }
    }

    return (
        <div>
            <Spin spinning={loading}>
                {
                    !hasOptinsFlag ? <Button type="link" icon="exclamation-circle" style={{ color: '#F84D50' }}>筛选项数据不完整,暂不支持选择</Button> : <div style={{ display: 'flex', alignItems: 'center' }}>
                        <Button type="link" icon="plus" onClick={() => handleAddCondition()}>新增条件</Button>
                        <Popconfirm title="确定全部删除吗？" onConfirm={() => handleDeleteAll()}>
                            <Button type="link" icon="delete" style={{ color: '#F84D50' }}>全部删除</Button>
                        </Popconfirm>
                    </div>
                }
            </Spin>
            {
                hasOptinsFlag ? <Row type="flex" className={`${styles.filterContainer}`}>
                    {filter.length > 1 ? <Col
                        span={1}
                        className={`${styles.relationCol} ${styles.showRelation}`}
                    >
                        <div className={styles.logicalBorder}></div>
                        <Tag
                            color="blue"
                            className={styles.customTag}
                            onClick={() => {
                                const newLogical = globalLogical === 'and' ? 'or' : 'and'
                                setGlobalLogical(newLogical)
                                setFieldsValue({
                                    rule_logical: newLogical,
                                })
                            }}
                        >
                            {globalLogical === 'or' ? '或' : '且'}
                        </Tag>
                    </Col> : null}
                    <Col span={23}>
                        {filter.map((cond, index) => (
                            <ConditionItem
                                key={`${index}`}
                                condition={cond}
                                index={index}
                                parentIndex={null}
                                onLogicalChange={handleLogicalChange}
                                onAddCondition={handleAddCondition}
                                onDeleteCondition={handleDeleteCondition}
                                filter={filter}
                                nullList={nullList}
                                onUpdateCondition={handleUpdateCondition}
                                ruleData={ruleData}
                            />
                        ))}
                    </Col>
                </Row> : null
            }
        </div>
    )
}

const ConditionItem = ({ filter, ruleData, condition, index, parentIndex, grandParentIndex = null, hideLogical = false, nullList, onLogicalChange, onAddCondition, onDeleteCondition, onUpdateCondition }) => {
    const isParent = parentIndex === null
    const isChildren = !isParent && grandParentIndex === null
    const showLogical = condition?.details?.length > 0 && !hideLogical
    return (
        // className = { styles.hoverRow }
        <Row style={{ paddingLeft: isParent ? 10 : 0 }}>
            <Row type="flex" className={styles.filterContainer}>
                {
                    showLogical ? <Col
                        span={1}
                        className={`${styles.relationCol} ${styles.showRelation}`}
                    >
                        <>
                            <div className={styles.logicalBorder}></div>
                            <Tag
                                color="blue"
                                className={styles.customTag}
                                onClick={() => onLogicalChange(index, condition.logical === 'and' ? 'or' : 'and', parentIndex)}
                            >
                                {condition.logical === 'or' ? '或' : '且'}
                            </Tag>
                        </>
                    </Col> : <Col span={1}></Col>
                }
                <Col span={showLogical ? 23 : 24} style={{ paddingLeft: isParent ? 10 : 0 }}>
                    {isParent && <div className={styles.filterItem}>
                        <CustomTargetFilterItem
                            index={index}
                            record={condition}
                            rule_data={ruleData}
                            onUpdateCondition={(obj, rIndex) => onUpdateCondition(obj, rIndex, null)}
                            nullList={nullList}
                        />
                        {
                            filter.length > 1 ? <Button size="small" type="link" icon="plus" onClick={() => onAddCondition(index, null)}></Button> : null
                        }
                        <Button size="small" type="link" icon="delete" onClick={() => onDeleteCondition(index, parentIndex)}></Button>
                    </div>}
                    {isChildren && <div className={styles.filterItem}>
                        <CustomTargetFilterItem
                            index={index}
                            record={condition}
                            rule_data={ruleData}
                            onUpdateCondition={(obj, rIndex) => onUpdateCondition(obj, rIndex, parentIndex)}
                            nullList={nullList}
                            parentIndex={parentIndex}
                        />
                        <Button size="small" type="link" icon="plus" onClick={() => onAddCondition(parentIndex, null)}></Button>
                        <Button size="small" type="link" icon="delete" onClick={() => onDeleteCondition(index, parentIndex)}></Button>
                    </div>}
                    {condition?.details?.map((child, childIndex) => (
                        <ConditionItem
                            key={`${index}_${childIndex}`}
                            condition={child}
                            index={childIndex}
                            parentIndex={index}
                            grandParentIndex={parentIndex}
                            onLogicalChange={onLogicalChange}
                            onAddCondition={onAddCondition}
                            onDeleteCondition={onDeleteCondition}
                            hideLogical={child?.children?.length === 0}
                            filter={filter}
                            nullList={nullList}
                            onUpdateCondition={onUpdateCondition}
                            ruleData={ruleData}
                        />
                    ))}
                </Col>
            </Row>
        </Row>
    )
}

export default CustomTargetFilter


