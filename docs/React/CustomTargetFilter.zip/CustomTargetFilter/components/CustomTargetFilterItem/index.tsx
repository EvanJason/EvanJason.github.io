import React, { useEffect, useState } from 'react'
import { Row, Select, Input, Cascader, Tooltip } from 'antd'
import { isNilLike } from '@/utils/tool'
import { isArray } from 'lodash'

interface Props {
    index: number
    record: AnyObj
    rule_data: any[]
    onUpdateCondition: Function
    nullList: any[]
    parentIndex?: number
}


const getPopupContainer = triggerNode => triggerNode?.parentNode

const CustomTargetFilterItem: React.FC<Props> = (props: Props) => {
    const { index, record, rule_data = [], onUpdateCondition, nullList, parentIndex } = props

    const [isNull, setIsNull] = useState(false)
    const [isOtherNull, setIsOtherNull] = useState(false)
    const [isArrayDataNull, setIsArrayDataNull] = useState(false)

    useEffect(() => {
        if (!isNilLike(parentIndex)) {
            if (nullList.includes(`${parentIndex}_${index}_value`)) {
                setIsNull(true)
            }
            if (nullList.includes(`${parentIndex}_${index}_other`)) {
                setIsOtherNull(true)
            }
            if (nullList.includes(`${parentIndex}_${index}_array`)) {
                setIsArrayDataNull(true)
            }
        } else {
            if (nullList.includes(`${index}_value`)) {
                setIsNull(true)
            }
            if (nullList.includes(`${index}_other`)) {
                setIsOtherNull(true)
            }
            if (nullList.includes(`${index}_array`)) {
                setIsArrayDataNull(true)
            }
        }
    }, [nullList])

    const displayRender = label => <span>{label[label.length - 1]}</span>

    const cascaderNameRender = () => {
        return (
            <>
                {record.group_name}
                {record.metric_name && <span>&nbsp;-&gt;&nbsp;{record.metric_name}</span>}
            </>
        )
    }

    const isArrayData = record.metric_type === 1 && ['in'].includes(record.operator)

    const changeConfig = (val, option) => {
        const [groups, metrics] = option
        const { metric_unit, duration, condition } = metrics || {}
        const { children, ...rest } = groups || {}
        const temp = {
            ...metrics,
            metric_unit: metric_unit ? metric_unit : [],
            ...rest,
            value: '',
            metric_duration: duration ? record.metric_type === 1 && Object.keys(condition)?.[0] === 'in' ? [] : Object.keys(duration)?.[0] : undefined,
            operator: condition ? Object.keys(condition)?.[0] : undefined,
            metric_unit_key: metric_unit?.[0]?.unit_key,
            metric_unit_name: metric_unit?.[0]?.unit_name,
            other_value: '',
        }
        onUpdateCondition(temp, index)
    }

    const updateRecord = obj => {
        onUpdateCondition(obj, index)
    }

    const ArrayDataNullStyle = { border: '1px solid red', outline: 'none', borderRadius: 4 }

    return (
        <Row key={index} style={{ display: 'flex', alignItems: 'center' }}>
            <Tooltip title={cascaderNameRender}>
                <Cascader
                    value={[record.group_id, record.metric_field]}
                    onChange={changeConfig}
                    allowClear={false}
                    options={rule_data}
                    placeholder="请选择"
                    style={{ width: 160, margin: 10 }}
                    fieldNames={{ label: 'group_name', value: 'group_id', children: 'children' }}
                    displayRender={displayRender}
                    showSearch
                    getPopupContainer={getPopupContainer}
                />
            </Tooltip>
            {record && Object.keys(record).length > 0 && (
                <>
                    {record.metric_type === 1 && <Select
                        getPopupContainer={getPopupContainer}
                        style={{ width: 100, marginRight: 10 }}
                        value={record.operator}
                        dropdownMatchSelectWidth={false}
                        onChange={val => {
                            updateRecord({
                                operator: val,
                                other_value: '',
                            })
                        }}
                    >
                        {Object.keys(record.condition).map(key => (
                            <Select.Option key={key} value={key}>
                                {record.condition[key]}
                            </Select.Option>
                        ))}
                    </Select>}
                    {/* <Tooltip title={record.duration && record.metric_duration ? renderDuration(record.metric_duration) : ''}> */}
                    <div style={{ position: 'relative' }}>
                        <Select
                            style={{ width: isArrayData ? 300 : 120, ...isArrayData && isArrayDataNull && ArrayDataNullStyle }}
                            getPopupContainer={getPopupContainer}
                            value={record.metric_duration}
                            dropdownMatchSelectWidth={false}
                            showSearch
                            optionFilterProp="children"
                            mode={isArrayData ? 'multiple' : 'default'}
                            onChange={val => {
                                if (isArrayData) {
                                    setIsArrayDataNull(!val || val.length === 0)
                                }
                                updateRecord({
                                    metric_duration: val,
                                })
                            }}
                        >
                            {record.duration && Object.keys(record.duration).map(key => (
                                <Select.Option key={key} value={key}>
                                    {record.duration[key]}
                                </Select.Option>
                            ))}
                        </Select>
                        {isArrayDataNull && (
                            <div style={{ position: 'absolute', color: 'red', left: 10, top: 26 }}>必填</div>
                        )}
                    </div>
                    {/* </Tooltip> */}
                    {record.metric_data_type === "NUMBER" && record.condition && Object.keys(record.condition).length > 0 && (
                        <Select
                            getPopupContainer={getPopupContainer}
                            style={{ width: 100, marginLeft: 10 }}
                            value={record.operator}
                            dropdownMatchSelectWidth={false}
                            onChange={val => {
                                updateRecord({
                                    operator: val,
                                    other_value: '',
                                })
                            }}
                        >
                            {Object.keys(record.condition).map(key => (
                                <Select.Option key={key} value={key}>
                                    {record.condition[key]}
                                </Select.Option>
                            ))}
                        </Select>
                    )}
                    {record.metric_data_type === "NUMBER" && (
                        <>
                            <div style={{ position: 'relative' }}>
                                <Input
                                    onChange={e => {
                                        const val = e.target.value.replace(/[^\d.]/, '')
                                        setIsNull(e.target.value === '')
                                        updateRecord({
                                            value: val,
                                        })
                                    }}
                                    value={record.value}
                                    placeholder="请输入"
                                    style={{
                                        width: 80,
                                        marginLeft: 10,
                                        marginRight: 5,
                                        border: isNull ? '1px solid red' : '1px solid #d9d9d9',
                                        outline: 'none',
                                    }}
                                />
                                {isNull && (
                                    <div style={{ position: 'absolute', color: 'red', left: 10, top: 26 }}>必填</div>
                                )}
                            </div>
                            {record.operator === 'between' && (
                                <div style={{ position: 'relative' }}>
                                    <span>—</span>
                                    <Input
                                        onChange={e => {
                                            const val = e.target.value.replace(/[^\d.]/, '')
                                            setIsOtherNull(e.target.value === '')
                                            updateRecord({
                                                other_value: val,
                                            })
                                        }}
                                        value={record.other_value}
                                        placeholder="请输入"
                                        style={{
                                            width: 80,
                                            marginLeft: 5,
                                            marginRight: 5,
                                            border: isOtherNull ? '1px solid red' : '1px solid #d9d9d9',
                                            outline: 'none',
                                        }}
                                    />
                                    {isOtherNull && (
                                        <div style={{ position: 'absolute', color: 'red', left: 10, top: 26 }}>
                                            必填
                                        </div>
                                    )}
                                </div>
                            )}
                            {
                                record.metric_unit?.length > 0 && <Select
                                    getPopupContainer={getPopupContainer}
                                    style={{ width: 80, marginLeft: 3 }}
                                    value={record.metric_unit_key}
                                    dropdownMatchSelectWidth={false}
                                    onChange={(val, option) => {
                                        updateRecord({
                                            metric_unit_key: val,
                                            metric_unit_name: option.props.name,
                                        })
                                    }}
                                >
                                    {record.metric_unit.map(item => (
                                        <Select.Option key={item.unit_key} value={item.unit_key} name={item.unit_name}>
                                            {item.unit_name}
                                        </Select.Option>
                                    ))}
                                </Select>
                            }
                        </>
                    )}
                </>
            )}
        </Row>
    )
}

export default CustomTargetFilterItem
